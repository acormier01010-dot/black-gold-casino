const socket = io();
const $ = id => document.getElementById(id);
let myId = null, roomState = null, myRoom = null, toastTimer;

socket.on("connect", () => { myId = socket.id; });
socket.on("joined", ({ code }) => { myRoom = code; $("lobby").classList.add("hidden"); $("table").classList.remove("hidden"); $("codeLabel").textContent = code; });
socket.on("state", state => { roomState = state; render(); });
socket.on("notice", message => toast(message));

$("createBtn").addEventListener("click", () => socket.emit("createRoom", { name: $("playerName").value }));
$("joinBtn").addEventListener("click", () => socket.emit("joinRoom", { name: $("playerName").value, code: $("roomCode").value }));
$("roomCode").addEventListener("input", e => e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0,5));
$("betBtn").addEventListener("click", () => socket.emit("placeBet", { amount: $("betAmount").value }));
$("dealBtn").addEventListener("click", () => socket.emit("deal"));
$("hitBtn").addEventListener("click", () => socket.emit("hit"));
$("standBtn").addEventListener("click", () => socket.emit("stand"));
$("nextBtn").addEventListener("click", () => socket.emit("startRound"));
$("leaveBtn").addEventListener("click", () => { location.reload(); });
$("copyBtn").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(myRoom || ""); toast("Code copié : " + myRoom); }
  catch { toast("Code de la table : " + myRoom); }
});

function toast(msg) {
  const el = $("toast"); el.textContent = msg; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
function fmt(n) { return Number(n || 0).toLocaleString("fr-CA"); }
function cardHtml(c) {
  if (c.hidden) return '<div class="card back" aria-label="Carte cachée"></div>';
  const red = c.suit === "♥" || c.suit === "♦" ? " red" : "";
  return `<div class="card${red}"><span>${c.rank}</span><span class="suit">${c.suit}</span></div>`;
}
function renderHand(cards) { return (cards || []).map(cardHtml).join(""); }
function statusFr(status) {
  return ({ waiting:"En attente", betting:"Doit miser", ready:"Mise placée", playing:"En jeu", stand:"Reste", bust:"Dépasse 21", blackjack:"Blackjack !", gagné:"Gagné", perdu:"Perdu", égalité:"Égalité", out:"Sans jetons" })[status] || status || "";
}
function render() {
  if (!roomState) return;
  const me = roomState.players.find(p => p.id === myId);
  $("codeLabel").textContent = roomState.code;
  $("statusMessage").textContent = roomState.message;
  $("dealerCards").innerHTML = renderHand(roomState.dealer.hand);
  $("dealerTotal").textContent = roomState.phase === "playing" ? "(carte visible : " + roomState.dealer.total + ")" : (roomState.phase === "waiting" || roomState.phase === "betting" ? "" : "(" + roomState.dealer.total + ")");
  $("players").innerHTML = roomState.players.map(p => {
    const isTurn = roomState.turnId === p.id;
    return `<article class="player${isTurn ? " current" : ""}">
      <div class="player-name">${escapeHtml(p.name)}${p.id === myId ? " (toi)" : ""}${p.isHost ? " ★" : ""}</div>
      <div class="player-meta">${fmt(p.chips)} jetons · Mise : ${fmt(p.bet)}</div>
      <div class="cards">${renderHand(p.hand)}</div>
      <div class="player-meta">${p.total === null ? "—" : "Total : " + p.total}</div>
      <div class="player-status">${statusFr(p.status)}${isTurn ? " · À TOI" : ""}</div>
    </article>`;
  }).join("");
  $("myChips").textContent = fmt(me ? me.chips : 0);
  const isHost = me && me.isHost;
  $("betBtn").disabled = roomState.phase !== "betting" || !me || me.bet > 0 || me.chips < 10;
  $("dealBtn").classList.toggle("hidden", roomState.phase !== "betting" || !isHost);
  $("dealBtn").disabled = roomState.phase !== "betting" || !roomState.players.some(p => p.bet > 0);
  $("hitBtn").disabled = roomState.phase !== "playing" || roomState.turnId !== myId;
  $("standBtn").disabled = roomState.phase !== "playing" || roomState.turnId !== myId;
  $("nextBtn").classList.toggle("hidden", !((roomState.phase === "waiting" || roomState.phase === "results") && isHost));
  $("turnHint").textContent = roomState.phase === "playing" ? (roomState.turnId === myId ? "C'est ton tour !" : "Tour de " + ((roomState.players.find(p => p.id === roomState.turnId) || {}).name || "…")) : roomState.phase === "betting" ? "Place ta mise, puis le créateur distribue." : roomState.phase === "results" ? "Manche terminée. Prêt pour la suivante ?" : "En attente des joueurs…";
  $("betAmount").max = Math.min(500, me ? me.chips : 500);
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c])); }
