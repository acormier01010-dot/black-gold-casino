# BLACK GOLD CASINO — Blackjack multijoueur

Jeu de blackjack dans le navigateur, interface française noir et or, tables privées de 1 à 6 joueurs, jetons virtuels. Les cartes et les résultats sont calculés côté serveur.

## Important avant de l'utiliser sur FlashFa

Cette application est un site Web externe. Elle ne se connecte pas à l'économie de GTA RP et n'effectue aucun paiement réel. Le fait que la tablette propose « Définir l'URL » ne garantit pas qu'elle accepte tous les sites : il faudra tester l'adresse hébergée dans FlashFa. Si la tablette utilise une liste blanche ou une interface spéciale, l'administrateur du serveur devra peut-être autoriser l'adresse.

## Déploiement conseillé (Render ou un autre hébergeur Node.js)

1. Décompresse le dossier.
2. Crée un dépôt GitHub et téléverse les fichiers du projet dans ce dépôt.
3. Sur un hébergeur qui accepte Node.js, crée un nouveau service Web relié au dépôt.
4. Configure :
   - Build command : `npm install`
   - Start command : `npm start`
5. Attends la fin du déploiement. Ouvre l'adresse HTTPS fournie par l'hébergeur.
6. Teste le jeu dans deux navigateurs différents : crée une table sur le premier, puis rejoins-la avec le code sur le second.
7. Si le test fonctionne, copie l'adresse HTTPS dans « Définir l'URL » sur la tablette FlashFa.

Les noms des menus peuvent changer selon l'hébergeur. Un service gratuit peut se mettre en veille et être lent à redémarrer.

## Jouer

- Entre un pseudo puis clique sur « Créer une table ».
- Les amis entrent leur pseudo et le code de 5 caractères pour rejoindre.
- Le créateur lance la manche.
- Chaque joueur place une mise de 10 à 500 jetons.
- Le créateur clique sur « Distribuer les cartes ».
- À ton tour, choisis « Tirer une carte » ou « Rester ».
- Le croupier tire jusqu'à 17. Les gains sont calculés automatiquement.
- Le créateur lance la manche suivante.

## Règles utilisées

- 2 à 6 joueurs par table; le serveur permet aussi de tester une table seul.
- Chaque joueur commence avec 1 000 jetons virtuels.
- Mise minimale : 10; maximale : 500.
- Blackjack naturel payé à 3:2 (gain total crédité = mise × 2,5, car la mise avait été retirée au départ).
- Égalité : la mise est rendue.
- Le croupier reste sur 17, y compris un 17 souple.
- Pas de partage de paire ni de double mise dans cette première version.

## Dépannage

- Si la page d'accueil s'ouvre mais que le jeu ne se connecte pas, vérifie que l'hébergeur prend en charge les WebSockets/Socket.IO.
- Si la page ne s'ouvre pas dans FlashFa, essaie l'adresse HTTPS dans ton navigateur normal. Si elle fonctionne à l'extérieur mais pas dans le jeu, la tablette ou le serveur peut bloquer les sites externes; contacte l'équipe FlashFa pour connaître les règles applicables.
- Les salles sont conservées en mémoire : si le serveur redémarre, les tables en cours sont supprimées.
- Ce projet est une base fonctionnelle, non un service de casino certifié. Pour un serveur public, ajoute une limitation de fréquence, une validation plus complète, des tests et une persistance si nécessaire.
