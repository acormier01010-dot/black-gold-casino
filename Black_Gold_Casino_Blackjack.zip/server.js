const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, app: "Black Gold Casino" }));

const rooms = new Map();
const STARTING_CHIPS = 1000;
const MAX_PLAYERS = 6;
const MIN_PLAYERS = 1; // Pour tester seul; les autres joueurs peuvent rejoindre la même salle.
const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

function newDeck() {
  const deck = [];
  for (const suit of SUITS) for (const rank of RANKS) deck.push({ suit, rank });
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}
function handValue(cards) {
  let total = 0, aces = 0;
  for (const c of cards) {
    if (c.rank === "A") { total += 11; aces++; }
    else if (["K", "Q", "J"].includes(c.rank)) total += 10;
    else total += Number(c.rank);
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}
function isBlackjack(cards) { return cards.length === 2 && handValue(cards) === 21; }
function roomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 5; i++) code += alphabet[Math.floor(Math.random() * alphabet.length)];
  return code;
}
function safeRoom(room) {
  const hideDealer = room.phase === "playing";
  return {
    code: room.code,
    hostId: room.hostId,
    phase: room.phase,
    message: room.message,
    players: room.players.map(p => ({
      id: p.id, name: p.name, chips: p.chips, bet: p.bet,
      hand: p.hand, total: p.hand.length ? handValue(p.hand) : null,
      status: p.status, isHost: p.id === room.hostId
    })),
    dealer: {
      hand: room.dealerHand.map((c, i) => hideDealer && i === 1 ? { hidden: true } : c),
      total: hideDealer ? (room.dealerHand.length ? handValue([room.dealerHand[0]]) : 0) : handValue(room.dealerHand)
    },
    turnId: room.turnId,
    minBet: 10,
    maxBet: 500
  };
}
function broadcast(room) {
  io.to(room.code).emit("state", safeRoom(room));
}
function say(room, text) { room.message = text; }
function startRound(room) {
  if (room.phase !== "waiting" && room.phase !== "results") return;
  const active = room.players.filter(p => p.chips >= 10);
  if (active.length < MIN_PLAYERS) return say(room, "Il faut au moins un joueur avec 10 jetons pour commencer.");
  room.deck = newDeck();
  room.dealerHand = [];
  room.turnId = null;
  for (const p of room.players) {
    p.hand = [];
    p.bet = 0;
    p.status = p.chips >= 10 ? "betting" : "out";
  }
  room.phase = "betting";
  say(room, "Choisissez votre mise, puis le croupier distribuera les cartes.");
  broadcast(room);
}
function dealRound(room) {
  const participants = room.players.filter(p => p.bet > 0);
  if (!participants.length) {
    room.phase = "waiting";
    say(room, "Personne n'a misé. Vous pouvez relancer une partie.");
    return broadcast(room);
  }
  room.deck = room.deck.length >= 15 ? room.deck : newDeck();
  for (let i = 0; i < 2; i++) {
    for (const p of participants) p.hand.push(room.deck.pop());
    room.dealerHand.push(room.deck.pop());
  }
  room.phase = "playing";
  for (const p of participants) p.status = isBlackjack(p.hand) ? "blackjack" : "playing";
  const first = participants.find(p => p.status === "playing");
  room.turnId = first ? first.id : null;
  say(room, "Les cartes sont distribuées. À vous de jouer !");
  if (!first) finishRound(room);
  else broadcast(room);
}
function nextTurn(room) {
  const idx = room.players.findIndex(p => p.id === room.turnId);
  const next = room.players.slice(idx + 1).find(p => p.status === "playing");
  if (next) {
    room.turnId = next.id;
    say(room, `Au tour de ${next.name}.`);
    broadcast(room);
  } else {
    room.turnId = null;
    dealerTurn(room);
  }
}
function dealerTurn(room) {
  room.phase = "dealer";
  while (handValue(room.dealerHand) < 17) room.dealerHand.push(room.deck.pop());
  finishRound(room);
}
function finishRound(room) {
  const dealerTotal = handValue(room.dealerHand);
  const dealerBJ = isBlackjack(room.dealerHand);
  for (const p of room.players) {
    if (p.bet <= 0) continue;
    const total = handValue(p.hand);
    if (p.status === "bust") {
      p.status = "perdu";
    } else if (isBlackjack(p.hand) && !dealerBJ) {
      p.chips += Math.floor(p.bet * 2.5); // mise rendue + gain 3:2
      p.status = "blackjack";
    } else if (dealerBJ && isBlackjack(p.hand)) {
      p.chips += p.bet;
      p.status = "égalité";
    } else if (dealerBJ) {
      p.status = "perdu";
    } else if (dealerTotal > 21 || total > dealerTotal) {
      p.chips += p.bet * 2;
      p.status = "gagné";
    } else if (total === dealerTotal) {
      p.chips += p.bet;
      p.status = "égalité";
    } else {
      p.status = "perdu";
    }
  }
  room.phase = "results";
  room.turnId = null;
  say(room, `Fin de la manche — croupier : ${dealerTotal}. Les résultats sont affichés sur la table.`);
  broadcast(room);
}
function getRoom(socket) {
  const code = socket.data.roomCode;
  return code ? rooms.get(code) : null;
}
function playerFor(room, socket) {
  return room && room.players.find(p => p.id === socket.id);
}
function emitError(socket, message) { socket.emit("notice", message); }

io.on("connection", socket => {
  socket.on("createRoom", ({ name }) => {
    name = String(name || "").trim().slice(0, 18);
    if (!name) return emitError(socket, "Entre un pseudo pour créer une table.");
    let code;
    do { code = roomCode(); } while (rooms.has(code));
    const room = {
      code, hostId: socket.id, phase: "waiting", message: "Bienvenue ! Créez une table et invitez vos amis avec le code.",
      players: [{ id: socket.id, name, chips: STARTING_CHIPS, bet: 0, hand: [], status: "waiting" }],
      dealerHand: [], deck: [], turnId: null
    };
    rooms.set(code, room);
    socket.join(code);
    socket.data.roomCode = code;
    socket.emit("joined", { code });
    broadcast(room);
  });

  socket.on("joinRoom", ({ name, code }) => {
    name = String(name || "").trim().slice(0, 18);
    code = String(code || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!name) return emitError(socket, "Entre un pseudo avant de rejoindre.");
    if (!room) return emitError(socket, "Cette table n'existe pas. Vérifie le code.");
    if (room.players.length >= MAX_PLAYERS) return emitError(socket, "Cette table est complète (6 joueurs maximum).");
    if (room.phase === "playing" || room.phase === "dealer") return emitError(socket, "Attends la fin de la manche avant de rejoindre cette table.");
    room.players.push({ id: socket.id, name, chips: STARTING_CHIPS, bet: 0, hand: [], status: "waiting" });
    socket.join(code);
    socket.data.roomCode = code;
    socket.emit("joined", { code });
    say(room, `${name} a rejoint la table.`);
    broadcast(room);
  });

  socket.on("startRound", () => {
    const room = getRoom(socket);
    if (!room) return;
    if (socket.id !== room.hostId) return emitError(socket, "Seul le créateur de la table peut lancer la manche.");
    if (room.phase === "waiting" || room.phase === "results") startRound(room);
  });

  socket.on("placeBet", ({ amount }) => {
    const room = getRoom(socket), p = playerFor(room, socket);
    if (!room || !p || room.phase !== "betting") return;
    amount = Math.floor(Number(amount));
    if (!Number.isFinite(amount) || amount < 10 || amount > 500) return emitError(socket, "La mise doit être entre 10 et 500 jetons.");
    if (amount > p.chips) return emitError(socket, "Tu n'as pas assez de jetons.");
    p.chips -= amount;
    p.bet = amount;
    p.status = "ready";
    say(room, `${p.name} a placé sa mise.`);
    broadcast(room);
  });

  socket.on("deal", () => {
    const room = getRoom(socket);
    if (!room || socket.id !== room.hostId || room.phase !== "betting") return;
    if (!room.players.some(p => p.bet > 0)) return emitError(socket, "Au moins un joueur doit miser avant la distribution.");
    dealRound(room);
  });

  socket.on("hit", () => {
    const room = getRoom(socket), p = playerFor(room, socket);
    if (!room || !p || room.phase !== "playing" || room.turnId !== socket.id) return;
    p.hand.push(room.deck.pop());
    const total = handValue(p.hand);
    if (total > 21) {
      p.status = "bust";
      say(room, `${p.name} dépasse 21.`);
      nextTurn(room);
    } else if (total === 21) {
      p.status = "stand";
      say(room, `${p.name} atteint 21.`);
      nextTurn(room);
    } else {
      say(room, `${p.name} tire une carte.`);
      broadcast(room);
    }
  });

  socket.on("stand", () => {
    const room = getRoom(socket), p = playerFor(room, socket);
    if (!room || !p || room.phase !== "playing" || room.turnId !== socket.id) return;
    p.status = "stand";
    say(room, `${p.name} reste.`);
    nextTurn(room);
  });

  socket.on("leaveRoom", () => leaveRoom(socket));
  socket.on("disconnect", () => leaveRoom(socket));
});

function leaveRoom(socket) {
  const room = getRoom(socket);
  if (!room) return;
  room.players = room.players.filter(p => p.id !== socket.id);
  socket.leave(room.code);
  socket.data.roomCode = null;
  if (!room.players.length) {
    rooms.delete(room.code);
    return;
  }
  if (room.hostId === socket.id) room.hostId = room.players[0].id;
  if (room.turnId === socket.id && room.phase === "playing") {
    room.turnId = null;
    const next = room.players.find(p => p.status === "playing");
    if (next) room.turnId = next.id;
    else dealerTurn(room);
  }
  say(room, "Un joueur a quitté la table.");
  broadcast(room);
}

server.listen(PORT, "0.0.0.0", () => console.log(`Black Gold Casino lancé sur le port ${PORT}`));
